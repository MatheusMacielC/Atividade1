package Negocio;

import Modelagem.Aluno;

public class Vetor {
	public Aluno[] alunos = new Aluno[3];
	
	public void adicionarEndereco(int posicao,Aluno aluno) {
	alunos [posicao] = aluno;
	
	}
	public void adicionarCpf(int posicao,Aluno aluno) {
	alunos [posicao] = aluno;
	
	}
	public void adicionarNumero(int posicao,Aluno aluno) {
		alunos [posicao] = aluno;
		
		}
	
	public void adicionarNome(int posicao,Aluno aluno) {
		alunos [posicao] = aluno;
		
		}
}