package Visao;

import javax.swing.JOptionPane;

import Modelagem.Aluno;
import Negocio.Vetor;

public class SistemaDeControle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		Aluno paulo = new Aluno();
		paulo.setNome(JOptionPane.showInputDialog(null,"digite o seu nome"));
		paulo.setEndereco(JOptionPane.showInputDialog(null,"digite o endereco"));
		paulo.setCpf(Integer.parseInt(JOptionPane.showInputDialog(null,"digite o cpf")));
		paulo.setNumero(Integer.parseInt(JOptionPane.showInputDialog(null,"digite o seu numero de telefone")));
		
		JOptionPane.showMessageDialog(null,paulo.getNome()+ "\n"+ paulo.getEndereco()+ "\n" + paulo.getCpf()+ "\n" + paulo.getNumero());
	
		
		
		//--------------------------------------------------------//
		
		Aluno marcos = new Aluno();
		marcos.setNome(JOptionPane.showInputDialog(null,"digite o seu nome"));
		marcos.setEndereco(JOptionPane.showInputDialog(null,"digite o endereco"));
		marcos.setCpf(Integer.parseInt(JOptionPane.showInputDialog(null,"digite o cpf" )));
		marcos.setNumero(Integer.parseInt(JOptionPane.showInputDialog(null,"digite o seu numero de telefone")));
		
		JOptionPane.showMessageDialog(null,marcos.getNome()+ "\n"+ marcos.getEndereco()+ "\n" + marcos.getCpf()+ "\n" + marcos.getNumero());
		
		
		//--------------------------------------------// 
		Aluno matheus = new Aluno();
		matheus.setNome(JOptionPane.showInputDialog(null,"digite o seu nome"));
		matheus.setEndereco(JOptionPane.showInputDialog(null,"digite o endereco"));
		matheus.setCpf(Integer.parseInt(JOptionPane.showInputDialog(null,"digite o cpf")));
		matheus.setNumero(Integer.parseInt(JOptionPane.showInputDialog(null,"digite o seu numero de telefone")));
		
		JOptionPane.showMessageDialog(null,matheus.getNome()+ "\n" + matheus.getEndereco()+ "\n" + matheus.getCpf()+ "\n" + matheus.getNumero());
		
		
		//-----------------------------//
		Vetor alunos = new Vetor();
		
		alunos.adicionarNome(0, paulo);
		alunos.adicionarNome(1, marcos);
		alunos.adicionarNome(2, matheus);
		
		alunos.adicionarEndereco(0, paulo);
		alunos.adicionarEndereco(1, marcos);
		alunos.adicionarEndereco(2, matheus);
		
		alunos.adicionarCpf(0, paulo);
		alunos.adicionarCpf(1, marcos);
		alunos.adicionarCpf(2, matheus);
		
		alunos.adicionarNumero(0, paulo);
		alunos.adicionarNumero(1, marcos);
		alunos.adicionarNumero(2, matheus);

	}

}
